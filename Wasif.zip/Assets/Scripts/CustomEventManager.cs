using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomEventManager : MonoBehaviour
{
    public delegate void BulletFired(float currentBullets, float totalBullets);
    public static event BulletFired OnBulletFired;

    public static void InvokeBulletFired(float currentBullets,float totalBullets)
    {
        OnBulletFired.Invoke(currentBullets, totalBullets);
    }
}
