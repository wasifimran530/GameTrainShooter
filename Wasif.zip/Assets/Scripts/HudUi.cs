using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HudUi : MonoBehaviour
{
    float totalBullets = 30;
    float currentBullets = 30;
    [SerializeField] Text BulletHud;
    private void Start()
    {
        currentBullets = 30;
        totalBullets = 30;
        UpdateText();
    }
    void UpdateText()
    {
        BulletHud.text = currentBullets.ToString() + "/" + totalBullets.ToString();
    }
    private void OnEnable()
    {
        CustomEventManager.OnBulletFired += UpdatePistolBulletUI;
    }
    private void OnDisable()
    {
        CustomEventManager.OnBulletFired -= UpdatePistolBulletUI;
    }
    public void UpdatePistolBulletUI(float _currentBullets, float _totalBullets)
    {
        totalBullets   = _totalBullets;
        currentBullets = _currentBullets;
        UpdateText();
    }
    public void UpdateGrenadeBulletUI(float _currentBullets, float _totalBullets)
    {
        totalBullets = _totalBullets;
        currentBullets = _currentBullets;
        UpdateText();
    }
}
