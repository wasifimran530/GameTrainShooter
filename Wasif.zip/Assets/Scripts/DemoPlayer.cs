using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DemoPlayer : MonoBehaviour
{
    [SerializeField] WeaponFactoryPistol pistolFactory;
    [SerializeField] WeaponFactoryGrenade grenadeFactory;
    IWeapon _currentWeapon;
    IWeapon[] totalWeapons;
    void Start()
    {
        IntializeWeaponForPlayer();
    }

    private void IntializeWeaponForPlayer()
    {
        totalWeapons = new IWeapon[3];
        totalWeapons[0] = pistolFactory.InitializeWeapon(_currentWeapon, this.transform);
        totalWeapons[1] = grenadeFactory.InitializeWeapon(_currentWeapon, this.transform);


        _currentWeapon = totalWeapons[0];
        _currentWeapon.SetWeaponMesh(true);
        _currentWeapon.WeaponSwitched();
    }

    // Update is called once per frame
    void Update()
    {
        // Handle Weapon
        HandleWeaponSwitch();

        // Select Input
        HandleInput();

    }

    private void HandleInput()
    {
        // For Shooting
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            _currentWeapon.Shoot();
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            _currentWeapon.Reload();
        }

        // To Get Player Name
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            string message = _currentWeapon.GetWeaponName();
            Debug.Log (message);
        }
    }

    private void HandleWeaponSwitch()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            _currentWeapon.SetWeaponMesh(false);
            _currentWeapon = totalWeapons[0];
            _currentWeapon.SetWeaponMesh(true);
            _currentWeapon.WeaponSwitched();
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            _currentWeapon.SetWeaponMesh(false);
            _currentWeapon = totalWeapons[1];
            _currentWeapon.SetWeaponMesh(true);
            _currentWeapon.WeaponSwitched();
        }
    }
}
