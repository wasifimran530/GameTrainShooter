using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IWeapon
{
    IWeapon Initialization();
    void Shoot();
    void Reload();
    void WeaponSwitched();
    void AudioPlay();
    void SetWeaponMesh(bool target);
    string GetWeaponName();
}
public abstract class WeaponFactory : MonoBehaviour
{
    public abstract IWeapon InitializeWeapon(IWeapon currentWeaponn, Transform player);
    public abstract string WeaponName(IWeapon currentWeapon);
}