using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pistol : MonoBehaviour, IWeapon
{
    [SerializeField] AudioSource sound;
    [SerializeField] GameObject mesh;
    [SerializeField] float currentBullets = 30;
    [SerializeField] float totalBullets = 30;
    // Start is called before the first frame update
    Pistol()
    {
        currentBullets = 30;
         totalBullets = 30;
    }
    public string GetWeaponName()
    {
        return "Pistol";
    }

    public IWeapon Initialization()
    {
        SetWeaponMesh(false);
        currentBullets = 30;
        totalBullets = 30;
        return this;
    }

    public void Shoot()
    {
        if (currentBullets <= 0)
        {
            return;
        }
        
        AudioPlay();
        GameManager.instance.totalBulletsFired += 1;
        currentBullets--;
        CustomEventManager.InvokeBulletFired(currentBullets, totalBullets);
        //Debug.Log("Pistol is shooting");
    }
    public void Reload()
    {
        if (currentBullets == totalBullets)
        {
            return;
        }
        currentBullets = 30;
        totalBullets = 30;
        CustomEventManager.InvokeBulletFired(currentBullets, totalBullets);
        //Debug.Log("Pistol is shooting");
    }
    public void SetWeaponMesh(bool target)
    {
        mesh.SetActive(target);
    }

    public void AudioPlay()
    {
        sound.Play();
    }

    public void WeaponSwitched()
    {
        CustomEventManager.InvokeBulletFired(currentBullets, totalBullets);
    }
}
