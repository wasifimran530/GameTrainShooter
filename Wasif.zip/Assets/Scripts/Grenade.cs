using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grenade : MonoBehaviour,IWeapon
{
    [SerializeField] AudioSource sound;
    [SerializeField] float CurrentGrenades = 5;
    [SerializeField] float TotalGrenades = 5;
    // Start is called before the first frame update

    Grenade()
    {
        CurrentGrenades = 5;
        TotalGrenades = 5;
    }
    public string GetWeaponName()
    {
        return "Grenade";
    }

    public IWeapon Initialization()
    {
        SetWeaponMesh(false);
        CurrentGrenades = 5;
        TotalGrenades = 5;
        return this;
    }

    public void Shoot()
    {
        if (CurrentGrenades <= 0)
        {
            return;
        }
        CurrentGrenades--;
        AudioPlay();
        CustomEventManager.InvokeBulletFired(CurrentGrenades, TotalGrenades);
        Debug.Log("Grenade Launched");
    }
    public void WeaponSwitched()
    {
        CustomEventManager.InvokeBulletFired(CurrentGrenades, TotalGrenades);
    }
    public void SetWeaponMesh(bool target)
    {
        this.GetComponent<MeshRenderer>().enabled = target;
    }

    public void AudioPlay()
    {
        sound.Play();
    }

    public void Reload()
    {
        if (CurrentGrenades == TotalGrenades)
        {
            return;
        }
        CurrentGrenades = 5;
        TotalGrenades = 5;
        CustomEventManager.InvokeBulletFired(CurrentGrenades, TotalGrenades);
    }
}
