using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponFactoryGrenade : WeaponFactory
{
    [SerializeField] private Grenade productPrefab;
    public override IWeapon InitializeWeapon(IWeapon currentWeapon, Transform player)
    {
        GameObject instance = Instantiate(productPrefab.gameObject, transform.position, Quaternion.identity,player);
        currentWeapon = instance.GetComponent<IWeapon>();
        currentWeapon.Initialization();
        return currentWeapon;
    }

    public override string WeaponName(IWeapon currentWeapon)
    {
        return currentWeapon.GetWeaponName();
    }

    // Start is called before the first frame update

}
