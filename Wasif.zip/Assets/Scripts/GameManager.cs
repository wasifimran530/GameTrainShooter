using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public int totalBulletsFired;
    public int totalDamageDelievered;
    public int totalCoinsCollected;
    private void Awake()
    {
        if (instance==null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else 
        {
        Destroy(gameObject);
        }
    }
    private void Start()
    {
        totalBulletsFired = 0;
        totalDamageDelievered = 0;
        totalCoinsCollected = 0;
    }
}
